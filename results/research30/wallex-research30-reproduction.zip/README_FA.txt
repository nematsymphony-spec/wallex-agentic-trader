پژوهش ۳۰روزه والکس؛ هیچ سفارش واقعی ثبت نشده است.
گزارش اصلی: docs/RESEARCH30_ALL_METHODS_FA.md
تمام سناریوها: results/research30/all-scenarios.csv
داده عمومی منجمد، کد، تست و نتایج همراه است. Python3 و NumPy لازم‌اند.
دستورها را از ریشه همین پوشه اجرا کنید:
PYTHONPATH=src:experiments OPENBLAS_NUM_THREADS=1 python3 experiments/research30.py
PYTHONPATH=src:experiments python3 experiments/research30_verify.py
PYTHONPATH=src:experiments python3 experiments/research30_controls.py
PYTHONPATH=src:experiments python3 experiments/research30_report.py
PYTHONPATH=src:experiments python3 -m unittest discover -s experiments -p test_research30.py -v
دفتر سفارش تاریخی موجود نیست؛ رتبه‌بندی تاریخی یک جایگزین صریح دارد. هیچ ادعای اجرای واقعی یا سود تضمین‌شده وجود ندارد.

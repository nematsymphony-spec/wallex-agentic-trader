See docs/MONTHLY_GOALS_FA.md. Python3 and NumPy required. All data and public API responses are frozen. No credentials or live trades.
